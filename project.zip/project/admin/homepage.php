<?php session_start();

?>
<!DOCTYPE HTML>
<html>

 <?php
      include('../dist/includes/dbcon.php');
      ?>
	<head>
		<title>Academic planning</title>
		<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>User | <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
<link href="css/style.css" rel="stylesheet" type="text/css"  media="all" />
		<link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="css/responsiveslides.css">
		<script src="jquery/jquery.min.js"></script>
		<script src="js/responsiveslides.min.js"></script>
		  <script>
		    // You can also use "$(window).load(function() {"
			    $(function () {
			
			      // Slideshow 1
			      $("#slider1").responsiveSlides({
			        maxwidth: 1600,
			        speed: 800
			      });
			});
		  </script>
	</head>
	<body>
		<!--start-wrap-->
		
			<!--start-header-->
			<div class="header">
				<div class="wrap">
				<!--start-logo-->
				
				<!-- <div class="logo">
					<a href="homepage.html" style="font-size: 30px; color:#3391E7; text-align: center;">Academic Planning Department</a>
				</div> -->
				<!--end-logo-->
				<!--start-top-nav-->
				
				<!--end-top-nav-->
			</div>
			<!--end-header-->
		</div>
		<p style="color: white;text-transform: uppercase; font-size: 25px; background-color: green"><marquee>Welcome to Academic Planning Department, Plateau State University Bokkos!!!</marquee></p>
		<p style="background-color: green; text-align: center; color: white"><a style="color: white;size: 40px " href="homepage.php">HOME</a> | | <a style="color: white" href="home.php">VIEW SCHEDULES</a></p>
				<div class="clear"> </div>
		<!-- <div class="clear"> </div> -->
			<!--start-image-slider---->
					<div class="image-slider">
						<!-- Slideshow 1 -->
					    <ul class="rslides" id="slider1">
					      <li><img src="images/staff.jpg"></li>
					      <li><img src="images/slider-images1.jpg"></li>
					      <li><img src="images/slider-images2.jpg"></li>
					      
					    </ul>
						 <!-- Slideshow 2 -->
					</div>
					<!--End-image-slider---->
		    <!-- <div class="clear"> </div> -->
		    <!-- <div class="content-grids">
		    	<div class="wrap">
		    	<div class="section group">
								
							
				<div class="listview_1_of_3 images_1_of_3">
					<div class="listimg listimg_1_of_2">
						  <img src="images/grid-img3.png">
					</div>
					<div class="text list_1_of_2">
						  <h3>Patients</h3>
						  <p>Register & Book Appointment</p>
						  <div class="button"><span><a href="hms/user-login.php">Click Here</a></span></div>
				    </div>
				</div>	

				<div class="listview_1_of_3 images_1_of_3">
					<div class="listimg listimg_1_of_2">
						  <img src="images/grid-img1.png">
					</div>
					<div class="text list_1_of_2">
						  <h3>Doctors Login</h3>
						
						  <div class="button"><span><a href="hms/doctor/">Click Here</a></span></div>
					</div>
				</div>


					<div class="listview_1_of_3 images_1_of_3">
					<div class="listimg listimg_1_of_2">
						  <img src="images/grid-img2.png">
					</div>
					<div class="text list_1_of_2">
						  <h3>Admin Login</h3>
						
						  <div class="button"><span><a href="hms/admin">Click Here</a></span></div>
				     </div>
				</div>			
			</div>
		    </div>
		   </div> -->

		   <div class="wrap">
		   <div class="content-box">
		   <div class="section group">
				<div class="col_1_of_3 span_1_of_3 frist">
				
				</div>
				<div class="col_1_of_3 span_1_of_3 second">
					
				</div>
				<div class="col_1_of_3 span_1_of_3 frist">
					
					
				</div>
			</div>
		   </div>
		   </div>
		   <!-- <div class="clear"> </div> -->
		   <div class="footer">
		   	 <div class="wrap">
		   <!-- 	<div class="footer-left">
		   			<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="contact.php">contact</a></li>
					</ul>
		   	</div>
 -->
		   
		   	<div id="credit"><p>Venue Allocation System 2018 &copy copyright</p></div>
		   	<div class="clear"> </div>
		   </div>
		   </div>
		<!--end-wrap-->
	</body>
</html>

