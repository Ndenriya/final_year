<?php session_start();

include('dist/includes/dbcon.php');

// if(isset($_POST['login']))
// {

// $user_unsafe=$_POST['username'];
// $pass_unsafe=$_POST['password'];

// $user = mysqli_real_escape_string($con,$user_unsafe);
// $pass = mysqli_real_escape_string($con,$pass_unsafe);

// $pass=md5($pass1);
// $salt="a1Bz20ydqelm8m1wql";
// $pass=$salt.$pass;
// if ($user=='Admin') {


// $sql ="SELECT * FROM member WHERE username ='$user' AND password='$pass'";
// $query=mysqli_query($con, $sql)or die(mysqli_error($con));
//  $counter=mysqli_num_rows($query);
//  if($counter >0){
//   while($row=mysqli_fetch_array($query)){
           
//            $name=$row['member_salut']." ".$row['member_first']." ".$row['member_last'];
          
    //        $id=$row['member_id'];
    //        $status=$row['status'];
    //        header('location:admin/home.php');
    //      }
    //    }
    //     else{ 
    //        echo "<script type='text/javascript'>alert('Invalid Username or Password!');
    //   document.location='index.php'</script>";
     
    //   }
    //   } 
    // elseif ($user==="Staff") {
      
   
//       $query=mysqli_query($con," SELECT * FROM admin WHERE username='$user' AND password='$pass'");

//       if(mysqli_num_rows($query)>0)
//      {
//     while($row=mysqli_fetch_assoc($query)){

//     header("location:admin/home.php");   
  
   

//       echo "you are logged in";  
        
//   }

// }

 // else
 //        {

 //          echo "<script type='text/javascript'>alert('invalid username or password');</script>";
 //        }
 //      }
     
    // } 
?> 


<?php include('dist/includes/dbcon.php'); ?>
<!DOCTYPE html>
<html>
  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Login - <?php include('dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition login-page" style="background:#burlywood">
   
    <div class="login-box">
      <div class="login-logo">
        <h3 style="color: green">TIMETABLE AND VENUE ALLOCATION SYSTEM(PLASU)</h3>
      </div><!-- /.login-logo -->
      <div class="login-box-body">
        <p class="login-box-msg">Sign in to start your session</p>
        <form action="login.php" method="post">
      <div class="form-group">
                <select class= "form-control" class="form-actions" name="username">
                  <!-- <option>Choose Login Type</option> -->
                  <option>Admin</option>
                  <option>Staff</option>
                  <option>Student</option>
                </select>  
        </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="Password" name="password">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
			<div class="col-xs-6 pull-right">
			  <button type="reset" class="btn btn-block btn-flat">Clear</button>
            </div><!-- /.col -->
			<div class="col-xs-6 pull-right">
              <button type="submit" class="btn btn-primary btn-block btn-flat" name="login">Sign In</button>
            </div><!-- /.col -->
          </div>
        </form>

        

      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->
      
           
   
<!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
  </body>
</html>
