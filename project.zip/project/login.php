<?php session_start();

include('dist/includes/dbcon.php');

if(isset($_POST['login']))
{

$user_unsafe=$_POST['username'];
$pass_unsafe=$_POST['password'];

$user = mysqli_real_escape_string($con,$user_unsafe);
$pass = mysqli_real_escape_string($con,$pass_unsafe);

/*$pass=md5($pass1);
$salt="a1Bz20ydqelm8m1wql";
$pass=$salt.$pass;*/
 if($user=='Admin'){
$sql ="SELECT * FROM member WHERE username ='$user' AND password='$pass'";
$query=mysqli_query($con, $sql)or die(mysqli_error($con));

if(mysqli_num_rows($query)>0){

while(	$row=mysqli_fetch_assoc($query)){  
           
           $name=$row['member_salut']." ".$row['member_first']." ".$row['member_last'];
                      $id=$row['member_id'];
           $status=$row['status'];
           $query=mysqli_query($con,"select * from settings where status='active'")or die(mysqli_error());
		$row=mysqli_fetch_array($query);		
	
		$_SESSION['settings']=$row['settings_id'];
		$_SESSION['term']=$row['term'];
	  	$_SESSION['id']=$id;	
	  	$_SESSION['name']=$name;	
	  	$_SESSION['type']=$status;	
	  		
		  	if ($status=='admin')
		  		{
				  
				 	echo "<script type='text/javascript'>document.location='admin/home.php'</script>";
 				 }
			  else
			  {

					echo "<script type='text/javascript'>document.location='admin/faculty_home.php'</script>";
				}
			
		   
  
      $_SESSION['settings']=$row['settings_id'];
      $_SESSION['term']=$row['term'];
      $_SESSION['id']=$id;  
      $_SESSION['name']=$name;  
      $_SESSION['type']=$status;  
        
  }
	  	 
		
	}
	else{
		echo "<script type='text/javascript'>alert('Invalid Username or Password!');
		  document.location='index.php'</script>";
	}
	  }

	  	
 elseif ($user=='Staff') {
$sql=mysqli_query($con,"SELECT * FROM user WHERE username='$user' AND password='$pass'");
if(mysqli_num_rows($sql)>0){
while($row=mysqli_fetch_assoc($sql)){
echo "<script type='text/javascript'>document.location='admin/home.php'</script>";	





}
}else
        {

         
	echo "<script type='text/javascript'>alert('invalid username or password');</script>"; 
        }




 }elseif($user=='Student'){
$sql=mysqli_query($con,"SELECT * FROM user WHERE username='$user' AND password='$pass'");
if(mysqli_num_rows($sql)>0){
while($row=mysqli_fetch_assoc($sql)){

echo "<script type='text/javascript'>document.location='student/home.php'</script>";	

 }
   }else
        {

          echo "<script type='text/javascript'>alert('invalid username or password');</script>";
        }

    }
   }	
	 
?>
